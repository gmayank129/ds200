#!/usr/bin/env python3

import matplotlib.pyplot as mlib
import pandas
import numpy as np

SO2 = []
NO2 = []
PM10 = []
dates = []
data = pandas.read_csv('cpcb_dly_aq_odisha-2015.csv')
for i in range (1,2392):
    if data['City/Town/Village/Area'][i] == 'Bhubaneswar':
        SO2.append(data['SO2'][i])
        NO2.append(data['NO2'][i])
        PM10.append(data['RSPM/PM10'][i])
        dates.append(data['Sampling Date'][i].rstrip('-15'))
ind = np.arange(len(dates))
mlib.scatter(PM10, NO2)
mlib.title('Scatter plot of PM10(x axis) vs NO2(y axis) in Bhubaneswar in 2015')
mlib.xlabel('PM10')
mlib.ylabel('NO2')
mlib.show()
