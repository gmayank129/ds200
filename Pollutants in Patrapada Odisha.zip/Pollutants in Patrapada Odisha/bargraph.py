#!/usr/bin/env python3

import matplotlib.pyplot as mlib
import pandas
import numpy as np

SO2 = []
NO2 = []
PM10 = []
dates = []
data = pandas.read_csv('cpcb_dly_aq_odisha-2015.csv')
for i in range (1,2392):
    if data['Location of Monitoring Station'][i] == 'Patrapada, Bhubneswar':
        SO2.append(data['SO2'][i])
        NO2.append(data['NO2'][i])
        PM10.append(data['RSPM/PM10'][i])
        dates.append(data['Sampling Date'][i].rstrip('-15'))
ind = np.arange(len(dates))
print(len(dates))
fig, ax = mlib.subplots()
rects = ax.bar(ind, PM10,0.1)
ax.set_title('PM10 levels  in Patrapada, Bhubaneshwar for different months in 2015')
ax.set_ylabel('Pollution')
ax.set_xlabel('Dates')
ax.set_xticklabels(dates)
mlib.show()
